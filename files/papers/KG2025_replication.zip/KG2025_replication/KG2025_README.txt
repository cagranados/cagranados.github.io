This folder contains a replication do-file for Kwak & Granados (2025),
Journal of Financial Stability.
DOI: https://doi.org/10.1016/j.jfs.2025.101433

Required input: KG2025_dataset_replication.dta
(not posted publicly due to data licensing constraints; available upon request).

To run: Open Stata, set the working directory to this folder,
and execute KG2025_replication.do.

Output: KG2025_FigureX.png will be created in the same folder.
